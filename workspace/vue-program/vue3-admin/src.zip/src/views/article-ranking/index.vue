<template>
  <div>article-ranking</div>
</template>
