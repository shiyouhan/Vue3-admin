<template>
  <div>article-detail</div>
</template>
